﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TotalCostOfFuelUsedByaCar
{
    internal class Program
    {
        public static bool IsValid(string id) // method IsValid()
        {
            if (id.Length != 3)
                return false;

            if (!char.IsUpper(id[0]))
                return false;

            if (!char.IsDigit(id[1]) || !char.IsDigit(id[2]))
                return false;

            return true;
        }

        public static string InputFuelType() // method InputFuelType()
        {
            string fuelType;
            bool isValidFuelType = false;

            do
            {
                Console.Write("Enter fuel type: "); // method to input fuel amount and fuel cost
                fuelType = Console.ReadLine();

                if (!IsValid(fuelType))
                    Console.WriteLine("Invalid fuel type. Please enter a valid fuel type.");

                isValidFuelType = IsValid(fuelType);

            } while (!isValidFuelType);

            return fuelType;
        }

        public static double InputPositiveNumericValue(string prompt) //method to input fuel amount and fuel cost
        {
            double value;
            bool isValidValue = false;

            do
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                isValidValue = double.TryParse(input, out value);

                if (!isValidValue || value <= 0)
                    Console.WriteLine("Invalid input. Please enter a valid positive numeric value.");

            } while (!isValidValue || value <= 0);

            return Math.Round(value, 2);
        }
        public static double CalculateFuelCost(double litresFilled, double costPerLitre) //method to calculate the total cost
        {
            return litresFilled * costPerLitre;
        }

        
        static void Main(string[] args) //Main() method
        {
            double litresFilled = InputPositiveNumericValue("Enter the number of litres of fuel filled: "); //method to input fuel amount
            string fuelType = InputFuelType(); //method to input Fuel Type
            double costPerLitre = InputPositiveNumericValue("Enter the cost of fuel per litre: ");//method to input cost of fuel

            double totalCost = CalculateFuelCost(litresFilled, costPerLitre);
            Console.WriteLine($"The number of litres of fuel: {litresFilled:F2}");
            Console.WriteLine($"Fuel type: {fuelType}");
            Console.WriteLine($"Cost of fuel: {costPerLitre:C}");
            Console.WriteLine($"Total cost of fuel: {totalCost:C}");
            Console.ReadKey();

        }
    }
}
